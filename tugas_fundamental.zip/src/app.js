import './styles/style.css';
import './script/component/app-bar.js';
import main from './script/view/main.js';
import 'regenerator-runtime';
document.addEventListener('DOMContentLoaded', main);